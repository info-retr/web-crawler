# web-crawler
project 2

### python3 main.py [CORPUS_DIR]



